<?php
$_lang['prop_mxcalendars.title_desc'] = 'Door komma gescheiden lijst van punten welke als titel gebruikt kunnen worden,in volgorde: bier, brouwer, locatie.';
$_lang['prop_mxcalendars.ascending'] = 'Oplopend';
$_lang['prop_mxcalendars.descending'] = 'Aflopend';
$_lang['prop_mxcalendars.dir_desc'] = 'Richting waarin de lijst wordt gesorteerd.';
$_lang['prop_mxcalendars.sort_desc'] = 'Veld gebruikt om te sorteren.';

$_lang['prop_mxcalendars.desc_theme'] = '';
//desc_detailid
$_lang['prop_mxcalendars.desc_displaytype'] = 'Dit is de standaard instelling, indien er geen displayType ingesteld wordt.';
$_lang['prop_mxcalendars.lt_calendar'] = 'agenda';
$_lang['prop_mxcalendars.lt_list'] = 'lijst';
$_lang['prop_mxcalendars.lt_mini'] = 'mini';
$_lang['prop_mxcalendars.desc_elstartdate'] = 'Startdatum evenementenlijst.';
$_lang['prop_mxcalendars.desc_elenddate'] = 'Stel hier in hoever vooruit agendapunten in evenementenlijst weergegeven moeten worden.';
$_lang['prop_mxcalendars.desc_tpllistitem'] = 'Chunk voor evenementen in evenementenlijst, stel bij eventListlimit het aantal agendapunten welke in lijst zichtbaar zijn in.';
$_lang['prop_mxcalendars.desc_tpllistheading'] = 'Chunk die standaard kop boven de lijst instelt.';
$_lang['prop_mxcalendars.desc_tpllistwrap'] = 'Buitenste chunk wrapper voor de evenementenlijst.';
$_lang['prop_mxcalendars.desc_tpldetail'] = 'Chunk welke gebruikt wordt om evenement detail weer te geven.';
$_lang['prop_mxcalendars.desc_dateformat'] = 'Standaard datum formaat dat de server gebruikt om data weer te geven.';
$_lang['prop_mxcalendars.desc_timeformat'] = 'Standaard tijd formaat dat de server gebruikt om tijden weer te geven.';
$_lang['prop_mxcalendars.desc_dateseperator'] = 'Stelt standaard datum scheidingsteken in "-" is standaard.';
$_lang['prop_mxcalendars.desc_activemonthonlyevents'] = 'Op "true" instellen om alleen de evenementen weer te geven van de maand welke op dat moment te zien is.';
$_lang['prop_mxcalendars.desc_highlighttoday'] = 'Boolean eigenschap (true/false) om de klasse te veranderen van de actuele dag in de agenda.';
$_lang['prop_mxcalendars.desc_todayclass'] = 'Stelt de naam in van knop om terug te gaan naar actuele datum.';
$_lang['prop_mxcalendars.desc_noeventclass'] = 'Stelt een speciale klasse in voor data welke geen agendapunten bevatten.';
$_lang['prop_mxcalendars.desc_haseventsclass'] = 'Stelt een speciale klasse in voor data welke agendapunten bevatten.';
$_lang['prop_mxcalendars.desc_tplevent'] = '';
$_lang['prop_mxcalendars.desc_tplday'] = '';
$_lang['prop_mxcalendars.desc_tplweek'] = '';
$_lang['prop_mxcalendars.desc_tplmonth'] = '';
$_lang['prop_mxcalendars.desc_tplheading'] = '';
$_lang['prop_mxcalendars.desc_debug'] = '';
$_lang['prop_mxcalendars.desc_googleMapAPIKey'] = 'Stel hier je persoonlijke Google Map V3 API Key in.';

$_lang['prop_mxcalendars.tpl'] = '';



$_lang['prop_mxcalendars.listing_type'] = 'Default listing type result set';
