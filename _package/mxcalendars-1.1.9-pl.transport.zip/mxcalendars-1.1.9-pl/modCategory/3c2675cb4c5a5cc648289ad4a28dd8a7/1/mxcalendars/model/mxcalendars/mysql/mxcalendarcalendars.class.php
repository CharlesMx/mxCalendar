<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendarcalendars.class.php');
class mxCalendarCalendars_mysql extends mxCalendarCalendars {}