<?php
class mxCalendarFeed extends xPDOSimpleObject {}