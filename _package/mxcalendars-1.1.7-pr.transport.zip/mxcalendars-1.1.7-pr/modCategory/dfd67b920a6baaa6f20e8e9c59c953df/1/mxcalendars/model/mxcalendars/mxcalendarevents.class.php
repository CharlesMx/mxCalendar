<?php
class mxCalendarEvents extends xPDOSimpleObject {}