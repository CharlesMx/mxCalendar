<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendarsettings.class.php');
class mxCalendarSettings_mysql extends mxCalendarSettings {}