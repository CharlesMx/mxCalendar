This extra is intended to be used to manage events via a single MODX management interface.
Provides multiple display options and allow full customization of the UI.
