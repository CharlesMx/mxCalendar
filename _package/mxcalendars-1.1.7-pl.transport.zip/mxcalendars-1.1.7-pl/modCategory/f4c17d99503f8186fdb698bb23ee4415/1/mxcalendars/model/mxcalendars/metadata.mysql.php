<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mxCalendarEvents',
    1 => 'mxCalendarEventImages',
    2 => 'mxCalendarEventWUG',
    3 => 'mxCalendarCategories',
    4 => 'mxCalendarCalendars',
    5 => 'mxCalendarSettings',
    6 => 'mxCalendarFeed',
    7 => 'mxCalendarLog',
  ),
);