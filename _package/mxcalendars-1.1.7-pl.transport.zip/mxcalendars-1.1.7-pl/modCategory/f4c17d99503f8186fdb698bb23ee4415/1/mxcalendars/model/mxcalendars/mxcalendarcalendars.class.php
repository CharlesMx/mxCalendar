<?php
class mxCalendarCalendars extends xPDOSimpleObject {}