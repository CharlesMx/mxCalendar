<?php
$_lang['prop_mxcalendars.title_desc'] = 'Разделённый запятой список названий';
$_lang['prop_mxcalendars.ascending'] = 'По возрастанию';
$_lang['prop_mxcalendars.descending'] = 'По убыванию';
$_lang['prop_mxcalendars.dir_desc'] = 'Направление сортировки';
$_lang['prop_mxcalendars.sort_desc'] = 'Сортировать по';

$_lang['prop_mxcalendars.desc_theme'] = '';
//desc_detailid
$_lang['prop_mxcalendars.desc_displaytype'] = 'Вид по умолчанию. Используется, если не задан displayType.';
$_lang['prop_mxcalendars.lt_calendar'] = 'календарь';
$_lang['prop_mxcalendars.lt_list'] = 'список';
$_lang['prop_mxcalendars.lt_mini'] = 'мини';
$_lang['prop_mxcalendars.desc_elstartdate'] = 'Дата начала';
$_lang['prop_mxcalendars.desc_elenddate'] = 'Дата конца';
$_lang['prop_mxcalendars.desc_tpllistitem'] = 'The inner most chunk for the event item in an event list';
$_lang['prop_mxcalendars.desc_tpllistheading'] = 'Default heading to place above the listing';
$_lang['prop_mxcalendars.desc_tpllistwrap'] = 'The outer most chunk wrapper for the event list';
$_lang['prop_mxcalendars.desc_tpldetail'] = 'Чанк, используемый для вида события';
$_lang['prop_mxcalendars.desc_dateformat'] = 'Умолчательный формат даты';
$_lang['prop_mxcalendars.desc_timeformat'] = 'Умолчательный формат времени';
$_lang['prop_mxcalendars.desc_dateseperator'] = 'Разделитель в формате даты (по умолчанию "-")';
$_lang['prop_mxcalendars.desc_activemonthonlyevents'] = 'Задание в "Да" приведёт к выводу событий только активного (просматриваемого) месяца';
$_lang['prop_mxcalendars.desc_highlighttoday'] = 'Выделить сегодняшний день в календаре';
$_lang['prop_mxcalendars.desc_todayclass'] = 'Укажите CSS-класс, с помощью которого выделить сегодняшний день в календаре';
$_lang['prop_mxcalendars.desc_noeventclass'] = 'Укажите CSS-класс для выделения дат без событий';
$_lang['prop_mxcalendars.desc_haseventsclass'] = 'Укажите CSS-класс для выделения дат с событиями';
$_lang['prop_mxcalendars.desc_tplevent'] = '';
$_lang['prop_mxcalendars.desc_tplday'] = '';
$_lang['prop_mxcalendars.desc_tplweek'] = '';
$_lang['prop_mxcalendars.desc_tplmonth'] = '';
$_lang['prop_mxcalendars.desc_tplheading'] = '';
$_lang['prop_mxcalendars.desc_debug'] = '';
$_lang['prop_mxcalendars.desc_googleMapAPIKey'] = 'Введите ваш персональный Google Map V3 API ключ для превышения ограничения на анонимные запросы';
$_lang['prop_mxcalendars.desc_googleMapRegion'] = 'Регион для Google Map API на основе CcTLD (https://ru.wikipedia.org/wiki/Национальный_домен_верхнего_уровня)';

$_lang['prop_mxcalendars.tpl'] = '';



$_lang['prop_mxcalendars.listing_type'] = 'Умолчательный тип вывода';
