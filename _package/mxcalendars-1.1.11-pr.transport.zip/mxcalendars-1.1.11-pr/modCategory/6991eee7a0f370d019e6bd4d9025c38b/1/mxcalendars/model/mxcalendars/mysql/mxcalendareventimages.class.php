<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendareventimages.class.php');
class mxCalendarEventImages_mysql extends mxCalendarEventImages {}