<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendareventvideos.class.php');
class mxCalendarEventVideos_mysql extends mxCalendarEventVideos {}